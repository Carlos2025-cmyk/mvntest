# jenkins-junit-maven-example
This is the maven basic project with Junit test cases for Jenkins integration.

